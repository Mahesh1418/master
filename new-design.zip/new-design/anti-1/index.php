<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Developer Portfolio</title>
    <meta name="description" content="Portfolio of a Creative Developer specializing in interactive web experiences.">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;700;900&display=swap" rel="stylesheet">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Outfit', 'sans-serif'],
                    },
                    colors: {
                        dark: '#0a0a0a',
                        primary: '#00f2ea',
                        secondary: '#ff0055',
                        glass: 'rgba(255, 255, 255, 0.05)',
                    }
                }
            }
        }
    </script>

    <style>
        body {
            background-color: #0a0a0a;
            color: #ffffff;
            overflow-x: hidden;
            cursor: none;
        }

        .cursor-dot,
        .cursor-outline {
            position: fixed;
            top: 0;
            left: 0;
            transform: translate(-50%, -50%);
            border-radius: 50%;
            z-index: 9999;
            pointer-events: none;
        }

        .cursor-dot {
            width: 8px;
            height: 8px;
            background-color: #00f2ea;
        }

        .cursor-outline {
            width: 40px;
            height: 40px;
            border: 1px solid #00f2ea;
            transition: width 0.2s, height 0.2s, background-color 0.2s;
        }

        /* Glassmorphism */
        .glass-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1rem;
        }

        /* Gradient Text */
        .text-gradient {
            background: linear-gradient(to right, #00f2ea, #ff0055);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .project-card:hover .project-image {
            transform: scale(1.05);
        }

        /* Floating Particles */
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: #00f2ea;
            border-radius: 50%;
            opacity: 0.3;
            animation: float 20s infinite;
        }

        .particle:nth-child(1) {
            left: 10%;
            animation-delay: 0s;
            animation-duration: 15s;
        }

        .particle:nth-child(2) {
            left: 20%;
            animation-delay: 2s;
            animation-duration: 18s;
        }

        .particle:nth-child(3) {
            left: 30%;
            animation-delay: 4s;
            animation-duration: 20s;
        }

        .particle:nth-child(4) {
            left: 40%;
            animation-delay: 1s;
            animation-duration: 22s;
        }

        .particle:nth-child(5) {
            left: 60%;
            animation-delay: 3s;
            animation-duration: 17s;
        }

        .particle:nth-child(6) {
            left: 70%;
            animation-delay: 5s;
            animation-duration: 19s;
        }

        .particle:nth-child(7) {
            left: 80%;
            animation-delay: 2.5s;
            animation-duration: 21s;
        }

        .particle:nth-child(8) {
            left: 90%;
            animation-delay: 4.5s;
            animation-duration: 16s;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(100vh) translateX(0);
                opacity: 0;
            }

            10%,
            90% {
                opacity: 0.3;
            }

            50% {
                transform: translateY(-10vh) translateX(50px);
            }
        }

        /* 3D Code Editor Styles */
        .perspective-1000 {
            perspective: 1000px;
        }

        .code-editor-card {
            transform-style: preserve-3d;
            backface-visibility: hidden;
            will-change: transform;
        }

        .animate-pulse-slow {
            animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        .typing-cursor {
            animation: blink 1s step-end infinite;
        }

        @keyframes blink {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }
        }
    </style>
</head>

<body class="antialiased selection:bg-primary selection:text-dark">

    <!-- Custom Cursor -->
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <!-- Navigation -->
    <nav
        class="fixed w-full z-50 top-0 left-0 px-6 py-4 flex justify-between items-center glass-card border-none rounded-none bg-dark/80 backdrop-blur-md">
        <a href="#" class="text-2xl font-bold tracking-tighter">DEV<span class="text-primary">.</span></a>
        <div class="hidden md:flex space-x-8 text-sm font-medium text-gray-300">
            <a href="#home" class="hover:text-primary transition-colors">Home</a>
            <a href="#about" class="hover:text-primary transition-colors">About</a>
            <a href="#work" class="hover:text-primary transition-colors">Work</a>
            <a href="#contact" class="hover:text-primary transition-colors">Contact</a>
        </div>
        <a href="#contact"
            class="px-6 py-2 border border-primary text-primary rounded-full text-sm font-medium hover:bg-primary hover:text-dark transition-all duration-300">Let's
            Talk</a>
    </nav>

    <!-- Hero Section -->
    <section id="home"
        class="min-h-screen flex flex-col justify-center items-center relative px-4 pt-20 overflow-hidden">
        <!-- Animated Grid Background -->
        <div class="absolute inset-0 pointer-events-none opacity-20">
            <div class="hero-grid absolute inset-0"
                style="background-image: linear-gradient(rgba(0, 242, 234, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 242, 234, 0.1) 1px, transparent 1px); background-size: 50px 50px;">
            </div>
        </div>

        <!-- Floating Particles -->
        <div class="particles absolute inset-0 pointer-events-none">
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
        </div>

        <!-- Glowing Orbs -->
        <div class="absolute inset-0 overflow-hidden pointer-events-none hero-shapes">
            <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[128px]"></div>
            <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-[128px]"></div>
            <div
                class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-[150px]">
            </div>
        </div>

        <div class="text-center z-10 max-w-7xl relative grid md:grid-cols-2 gap-12 items-center">
            <!-- Text Content (Left) -->
            <div class="text-left order-2 md:order-1">
                <p class="hero-subtitle text-primary font-medium tracking-widest mb-4 opacity-0 translate-y-4">HELLO,
                    I'M MAHESH S</p>
                <h1
                    class="hero-title text-5xl md:text-8xl font-black tracking-tight leading-[0.9] mb-8 overflow-hidden relative">
                    <span class="inline-block translate-y-full hero-word-1">WORDPRESS</span><br>
                    <span class="inline-block translate-y-full text-gradient hero-word-2 relative">
                        DEVELOPER
                        <div
                            class="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-primary via-secondary to-primary opacity-0 hero-underline">
                        </div>
                    </span>
                </h1>
                <p
                    class="hero-desc text-gray-400 text-lg md:text-xl max-w-xl mb-10 opacity-0 translate-y-4 leading-relaxed">
                    I craft <span class="text-white font-semibold">seamless, responsive user interfaces</span> using
                    Angular and build dynamic, <span class="text-primary">SEO-optimized WordPress websites</span>.
                </p>
                <div class="hero-btn opacity-0 translate-y-4 flex gap-4 flex-wrap">
                    <a href="#work"
                        class="group relative inline-flex items-center gap-2 px-8 py-4 bg-white text-dark rounded-full font-bold overflow-hidden shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-shadow">
                        <span class="relative z-10">View My Work</span>
                        <div
                            class="absolute inset-0 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300">
                        </div>
                    </a>
                    <a href="#contact"
                        class="group relative inline-flex items-center gap-2 px-8 py-4 border-2 border-primary text-primary rounded-full font-bold overflow-hidden hover:text-dark transition-colors">
                        <span class="relative z-10">Let's Talk</span>
                        <div
                            class="absolute inset-0 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300">
                        </div>
                    </a>
                </div>
            </div>

            <!-- 3D Code Editor (Right) -->
            <div class="relative order-1 md:order-2 perspective-1000">
                <div class="absolute inset-0 pointer-events-none code-particles"></div>
                <div
                    class="code-editor-card glass-card rounded-xl overflow-hidden shadow-2xl transform transition-transform duration-500 hover:scale-[1.02] border border-gray-700/50 bg-[#1e1e1e]/80 backdrop-blur-xl">
                    <div class="bg-[#252526] px-4 py-3 flex items-center gap-2 border-b border-gray-700">
                        <div class="flex gap-2">
                            <div class="w-3 h-3 rounded-full bg-red-500"></div>
                            <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                            <div class="w-3 h-3 rounded-full bg-green-500"></div>
                        </div>
                        <div class="ml-4 text-xs text-gray-400 font-mono">developer.ts</div>
                    </div>
                    <div
                        class="p-6 font-mono text-sm md:text-base leading-relaxed text-left h-[300px] overflow-hidden relative">
                        <div class="absolute left-4 top-6 text-gray-600 select-none text-right">
                            1<br>2<br>3<br>4<br>5<br>6<br>7<br>8<br>9<br>10<br>11</div>
                        <div class="pl-8 code-content text-gray-300">
                            <span class="text-purple-400">class</span> <span class="text-yellow-400">Developer</span>
                            {<br>
                            &nbsp;&nbsp;<span class="text-purple-400">constructor</span>() {<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;<span class="text-blue-400">this</span>.<span
                                class="text-blue-300">name</span> = <span class="text-green-400">"Mahesh S"</span>;<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;<span class="text-blue-400">this</span>.<span
                                class="text-blue-300">skills</span> = [<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-green-400">"Angular"</span>,<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-green-400">"WordPress"</span>,<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="text-green-400">"Creative UI"</span><br>
                            &nbsp;&nbsp;&nbsp;&nbsp;];<br>
                            &nbsp;&nbsp;}<br>
                            <br>
                            &nbsp;&nbsp;<span class="text-yellow-400">createMagic</span>() {<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;<span class="text-purple-400">return</span> <span
                                class="text-green-400">"Mesmerizing Experiences"</span>;<br>
                            &nbsp;&nbsp;}<br>
                            }<br>
                            <span
                                class="typing-cursor inline-block w-2 h-5 bg-primary align-middle animate-pulse"></span>
                        </div>
                    </div>
                </div>
                <div
                    class="absolute -inset-4 bg-gradient-to-r from-primary to-secondary opacity-20 blur-2xl -z-10 rounded-full animate-pulse-slow">
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-24 px-6 relative overflow-hidden">
        <div class="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
            <div class="relative about-image opacity-0 -translate-x-10">
                <div class="aspect-square rounded-2xl overflow-hidden relative z-10">
                    <div class="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 mix-blend-overlay">
                    </div>
                    <img src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=1000&auto=format&fit=crop"
                        alt="Mahesh S"
                        class="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500">
                </div>
                <div
                    class="absolute -bottom-6 -right-6 w-48 h-48 bg-dark border border-gray-700 rounded-xl p-4 flex flex-col justify-center items-center z-20 shadow-2xl">
                    <span class="text-4xl font-bold text-primary">3+</span>
                    <span class="text-gray-400 text-sm uppercase tracking-wider mt-2">Years Exp.</span>
                </div>
                <div class="absolute -top-4 -left-4 w-full h-full border-2 border-primary/30 rounded-2xl -z-10"></div>
            </div>
            <div class="about-content opacity-0 translate-x-10">
                <span class="text-primary tracking-widest text-sm font-bold uppercase">About Me</span>
                <h2 class="text-4xl md:text-5xl font-bold mt-2 mb-6">Passionate about creating <span
                        class="text-gradient">digital experiences</span></h2>
                <p class="text-gray-400 text-lg mb-6 leading-relaxed">I am a dedicated Front-End Developer with a strong
                    foundation in Angular and WordPress. My journey involves turning complex problems into simple,
                    beautiful, and intuitive interface designs.</p>
                <p class="text-gray-400 text-lg mb-8 leading-relaxed">When I'm not coding, you can find me exploring new
                    web technologies, contributing to open-source projects, or refining my design skills.</p>
                <div class="flex flex-wrap gap-4">
                    <div class="flex items-center gap-2 text-gray-300"><span
                            class="w-2 h-2 rounded-full bg-primary"></span><span>Problem Solver</span></div>
                    <div class="flex items-center gap-2 text-gray-300"><span
                            class="w-2 h-2 rounded-full bg-secondary"></span><span>Creative Thinker</span></div>
                    <div class="flex items-center gap-2 text-gray-300"><span
                            class="w-2 h-2 rounded-full bg-purple-500"></span><span>Team Player</span></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-32 px-6 relative overflow-hidden bg-dark/50">
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-[120px] pointer-events-none">
        </div>
        <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px] pointer-events-none">
        </div>
        <div class="max-w-7xl mx-auto relative z-10">
            <div class="text-center mb-20 feature-header opacity-0">
                <span class="text-primary tracking-widest text-sm font-bold uppercase">Features</span>
                <h2 class="text-4xl md:text-6xl font-bold mt-2 mb-6">What I Do</h2>
                <p class="text-gray-400 text-lg max-w-3xl mx-auto">Specialized skills and capabilities that make
                    projects come alive with stunning visuals and seamless functionality</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8 mb-20">
                <div class="feature-card opacity-0 translate-y-10">
                    <div
                        class="glass-card p-8 rounded-2xl hover:border-primary/30 transition-all duration-500 group relative overflow-hidden h-full">
                        <div
                            class="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                        </div>
                        <div class="relative mb-6">
                            <div
                                class="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                                <span class="text-3xl">🎨</span>
                            </div>
                        </div>
                        <h3 class="text-2xl font-bold mb-4 group-hover:text-primary transition-colors">UI/UX Development
                        </h3>
                        <p class="text-gray-400 mb-6 leading-relaxed">Crafting responsive, pixel-perfect interfaces
                            focused on performance and user experience.</p>
                    </div>
                </div>
                <div class="feature-card opacity-0 translate-y-10">
                    <div
                        class="glass-card p-8 rounded-2xl hover:border-secondary/30 transition-all duration-500 group relative overflow-hidden h-full">
                        <div
                            class="absolute inset-0 bg-gradient-to-br from-secondary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                        </div>
                        <div class="relative mb-6">
                            <div
                                class="w-16 h-16 rounded-xl bg-secondary/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                                <span class="text-3xl">🅰️</span>
                            </div>
                        </div>
                        <h3 class="text-2xl font-bold mb-4 group-hover:text-secondary transition-colors">Angular
                            Development</h3>
                        <p class="text-gray-400 mb-6 leading-relaxed">Building scalable, dynamic single-page
                            applications using Angular for modern web solutions.</p>
                    </div>
                </div>
                <div class="feature-card opacity-0 translate-y-10">
                    <div
                        class="glass-card p-8 rounded-2xl hover:border-purple-500/30 transition-all duration-500 group relative overflow-hidden h-full">
                        <div
                            class="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                        </div>
                        <div class="relative mb-6">
                            <div
                                class="w-16 h-16 rounded-xl bg-purple-500/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                                <span class="text-3xl">📝</span>
                            </div>
                        </div>
                        <h3 class="text-2xl font-bold mb-4 group-hover:text-purple-400 transition-colors">WordPress
                            Development</h3>
                        <p class="text-gray-400 mb-6 leading-relaxed">Creating custom WordPress themes and plugins
                            tailored to business goals and SEO needs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Work Section -->
    <section id="work" class="py-24 px-6 bg-dark/50">
        <div class="max-w-6xl mx-auto">
            <div class="flex justify-between items-end mb-16">
                <div>
                    <span class="text-primary tracking-widest text-sm font-bold uppercase">Portfolio</span>
                    <h2 class="text-4xl md:text-6xl font-bold mt-2">Selected Work</h2>
                </div>
                <a href="#" class="hidden md:block text-gray-400 hover:text-white transition-colors">View All Projects
                    -></a>
            </div>
            <div class="grid md:grid-cols-2 gap-8">
                <div class="project-card group cursor-pointer">
                    <div class="aspect-video rounded-xl overflow-hidden mb-6 relative">
                        <div
                            class="absolute inset-0 bg-gray-800 project-image transition-transform duration-700 ease-out">
                            <div
                                class="w-full h-full flex items-center justify-center bg-gradient-to-tr from-purple-900 to-indigo-900">
                                <span class="text-4xl">🛒</span>
                            </div>
                        </div>
                        <div
                            class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <span
                                class="px-6 py-3 bg-white text-dark rounded-full font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">View
                                Project</span>
                        </div>
                    </div>
                    <h3 class="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">sparesdeal</h3>
                    <p class="text-gray-400">E-commerce Platform</p>
                </div>
                <div class="project-card group cursor-pointer md:mt-16">
                    <div class="aspect-video rounded-xl overflow-hidden mb-6 relative">
                        <div
                            class="absolute inset-0 bg-gray-800 project-image transition-transform duration-700 ease-out">
                            <div
                                class="w-full h-full flex items-center justify-center bg-gradient-to-tr from-pink-900 to-red-900">
                                <span class="text-4xl">📖</span>
                            </div>
                        </div>
                        <div
                            class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <span
                                class="px-6 py-3 bg-white text-dark rounded-full font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">View
                                Project</span>
                        </div>
                    </div>
                    <h3 class="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">storyjourney</h3>
                    <p class="text-gray-400">Interactive Storytelling</p>
                </div>
                <div class="project-card group cursor-pointer">
                    <div class="aspect-video rounded-xl overflow-hidden mb-6 relative">
                        <div
                            class="absolute inset-0 bg-gray-800 project-image transition-transform duration-700 ease-out">
                            <div
                                class="w-full h-full flex items-center justify-center bg-gradient-to-tr from-green-900 to-teal-900">
                                <span class="text-4xl">💼</span>
                            </div>
                        </div>
                        <div
                            class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <span
                                class="px-6 py-3 bg-white text-dark rounded-full font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">View
                                Project</span>
                        </div>
                    </div>
                    <h3 class="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">bmesolutions</h3>
                    <p class="text-gray-400">Corporate Website</p>
                </div>
                <div class="project-card group cursor-pointer md:mt-16">
                    <div class="aspect-video rounded-xl overflow-hidden mb-6 relative">
                        <div
                            class="absolute inset-0 bg-gray-800 project-image transition-transform duration-700 ease-out">
                            <div
                                class="w-full h-full flex items-center justify-center bg-gradient-to-tr from-yellow-900 to-orange-900">
                                <span class="text-4xl">🕶️</span>
                            </div>
                        </div>
                        <div
                            class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <span
                                class="px-6 py-3 bg-white text-dark rounded-full font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">View
                                Project</span>
                        </div>
                    </div>
                    <h3 class="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">zealousxr</h3>
                    <p class="text-gray-400">XR/VR Experience</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="py-24 px-6 relative overflow-hidden">
        <div
            class="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px] pointer-events-none">
        </div>
        <div
            class="absolute bottom-0 left-0 w-[500px] h-[500px] bg-secondary/5 rounded-full blur-[100px] pointer-events-none">
        </div>
        <div class="max-w-6xl mx-auto relative z-10">
            <div class="text-center mb-20">
                <span class="text-primary tracking-widest text-sm font-bold uppercase">Expertise</span>
                <h2 class="text-4xl md:text-6xl font-bold mt-2">Professional Skills</h2>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🌐</div>
                    <h3 class="font-bold">HTML5</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🎨</div>
                    <h3 class="font-bold">CSS3</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">⚡</div>
                    <h3 class="font-bold">JavaScript</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🅱️</div>
                    <h3 class="font-bold">Bootstrap</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🌊</div>
                    <h3 class="font-bold">Tailwind CSS</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">💅</div>
                    <h3 class="font-bold">Sass</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">📝</div>
                    <h3 class="font-bold">WordPress</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🅰️</div>
                    <h3 class="font-bold">Angular</h3>
                </div>
                <div
                    class="skill-card glass-card p-6 rounded-2xl text-center hover:-translate-y-2 transition-transform duration-300 group">
                    <div class="text-4xl mb-3 group-hover:scale-110 transition-transform">🐙</div>
                    <h3 class="font-bold">GitHub</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Resume Section -->
    <section id="resume" class="py-32 px-6 relative bg-dark/30">
        <div class="absolute top-1/2 left-0 w-96 h-96 bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
        <div class="absolute top-1/4 right-0 w-96 h-96 bg-secondary/5 rounded-full blur-[120px] pointer-events-none">
        </div>
        <div class="max-w-6xl mx-auto relative z-10">
            <div class="text-center mb-20">
                <span class="text-primary tracking-widest text-sm font-bold uppercase">My Journey</span>
                <h2 class="text-4xl md:text-6xl font-bold mt-2 mb-6">Experience & Education</h2>
                <p class="text-gray-400 text-lg max-w-2xl mx-auto">3+ Years of Experience in Web Development</p>
            </div>
            <div class="grid md:grid-cols-2 gap-12">
                <div class="resume-experience">
                    <h3 class="text-2xl font-bold mb-8 flex items-center gap-3"><span
                            class="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">💼</span>Job
                        Experience</h3>
                    <div class="relative pl-8 space-y-8">
                        <div class="absolute left-0 top-0 bottom-0 w-[2px] bg-gray-800 overflow-hidden">
                            <div
                                class="timeline-light absolute top-0 left-0 w-full h-[100px] bg-gradient-to-b from-transparent via-primary to-transparent -translate-y-full">
                            </div>
                        </div>
                        <div class="experience-item relative opacity-0 translate-x-4">
                            <div
                                class="absolute -left-[33px] top-0 w-4 h-4 rounded-full bg-primary border-4 border-dark z-10">
                            </div>
                            <div
                                class="glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 group">
                                <div class="flex justify-between items-start mb-3 flex-wrap gap-2">
                                    <div>
                                        <h4 class="text-xl font-bold group-hover:text-primary transition-colors">Front
                                            End Developer</h4>
                                        <p class="text-primary text-sm font-medium">Zealous Service</p>
                                    </div>
                                    <span class="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">2024 -
                                        Present</span>
                                </div>
                                <p class="text-gray-400 text-sm leading-relaxed">Specialized in crafting responsive and
                                    accessible user interfaces using modern front-end technologies like HTML5, CSS3,
                                    JavaScript, and Angular.</p>
                            </div>
                        </div>
                        <div class="experience-item relative opacity-0 translate-x-4">
                            <div
                                class="absolute -left-[33px] top-0 w-4 h-4 rounded-full bg-secondary border-4 border-dark z-10">
                            </div>
                            <div
                                class="glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 group">
                                <div class="flex justify-between items-start mb-3 flex-wrap gap-2">
                                    <div>
                                        <h4 class="text-xl font-bold group-hover:text-primary transition-colors">
                                            Software Developer</h4>
                                        <p class="text-primary text-sm font-medium">BM e-Solutions</p>
                                    </div>
                                    <span class="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">2021 -
                                        2023</span>
                                </div>
                                <p class="text-gray-400 text-sm leading-relaxed">Developed and maintained web
                                    applications using HTML, CSS, JavaScript, and WordPress. Collaborated with
                                    cross-functional teams.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="resume-experience">
                    <h3 class="text-2xl font-bold mb-8 flex items-center gap-3"><span
                            class="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">🎓</span>Education
                    </h3>
                    <div class="relative pl-8 space-y-8">
                        <div class="absolute left-0 top-0 bottom-0 w-[2px] bg-gray-800 overflow-hidden">
                            <div
                                class="timeline-light absolute top-0 left-0 w-full h-[100px] bg-gradient-to-b from-transparent via-primary to-transparent -translate-y-full">
                            </div>
                        </div>
                        <div class="experience-item relative opacity-0 translate-x-4">
                            <div
                                class="absolute -left-[33px] top-0 w-4 h-4 rounded-full bg-primary border-4 border-dark z-10">
                            </div>
                            <div class="glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 group">
                                <div class="flex justify-between items-start mb-3 flex-wrap gap-2">
                                    <div>
                                        <h4 class="text-xl font-bold group-hover:text-primary transition-colors">
                                            Bachelor's Degree</h4>
                                        <p class="text-primary text-sm font-medium">University</p>
                                    </div>
                                    <span class="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">2017 -
                                        2021</span>
                                </div>
                                <p class="text-gray-400 text-sm leading-relaxed">Computer Science / Information
                                    Technology</p>
                            </div>
                        </div>
                        <div class="experience-item relative opacity-0 translate-x-4">
                            <div
                                class="absolute -left-[33px] top-0 w-4 h-4 rounded-full bg-secondary border-4 border-dark z-10">
                            </div>
                            <div class="glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 group">
                                <div class="flex justify-between items-start mb-3 flex-wrap gap-2">
                                    <div>
                                        <h4 class="text-xl font-bold group-hover:text-primary transition-colors">
                                            Bachelor's Degree</h4>
                                        <p class="text-primary text-sm font-medium">University</p>
                                    </div>
                                    <span class="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">2017 -
                                        2021</span>
                                </div>
                                <p class="text-gray-400 text-sm leading-relaxed">Computer Science / Information
                                    Technology</p>
                            </div>
                        </div>
                        <div class="experience-item relative opacity-0 translate-x-4">
                            <div
                                class="absolute -left-[33px] top-0 w-4 h-4 rounded-full bg-secondary border-4 border-dark z-10">
                            </div>
                            <div class="glass-card p-6 rounded-xl hover:border-primary/30 transition-all duration-300 group">
                                <div class="flex justify-between items-start mb-3 flex-wrap gap-2">
                                    <div>
                                        <h4 class="text-xl font-bold group-hover:text-primary transition-colors">
                                            Bachelor's Degree</h4>
                                        <p class="text-primary text-sm font-medium">University</p>
                                    </div>
                                    <span class="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full">2017 -
                                        2021</span>
                                </div>
                                <p class="text-gray-400 text-sm leading-relaxed">Computer Science / Information
                                    Technology</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-16 text-center resume-cta opacity-0">
                <div class="glass-card inline-block p-8 rounded-2xl">
                    <h3 class="text-2xl font-bold mb-4">Interested in working together?</h3>
                    <p class="text-gray-400 mb-6 max-w-md mx-auto">Download my full resume to learn more about my
                        experience and skills.</p>
                    <a href="#"
                        class="group inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-primary to-secondary text-dark rounded-full font-bold hover:shadow-2xl hover:shadow-primary/50 transition-all duration-300">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                            class="group-hover:translate-y-1 transition-transform">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                        Download Resume
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-24 px-6 relative">
        <div class="max-w-4xl mx-auto text-center">
            <span class="text-primary tracking-widest text-sm font-bold uppercase">Get In Touch</span>
            <h2 class="text-4xl md:text-6xl font-bold mt-2 mb-8">Let's Work Together</h2>
            <p class="text-gray-400 text-xl mb-12 max-w-2xl mx-auto">Have a project in mind or just want to say hello?
                I'm always open to discussing new projects, creative ideas or opportunities to be part of your visions.
            </p>
            <a href="mailto:contact@example.com"
                class="inline-flex items-center gap-3 px-10 py-5 bg-white text-dark rounded-full font-bold text-lg hover:shadow-2xl hover:shadow-primary/50 transition-all duration-300 hover:-translate-y-1">
                <span>👋</span> Say Hello
            </a>
            <div class="flex justify-center gap-8 mt-16">
                <a href="#" class="text-gray-400 hover:text-primary transition-colors text-2xl">GitHub</a>
                <a href="#" class="text-gray-400 hover:text-primary transition-colors text-2xl">LinkedIn</a>
                <a href="#" class="text-gray-400 hover:text-primary transition-colors text-2xl">Twitter</a>
            </div>
        </div>
    </section>

    <footer class="py-8 text-center text-gray-600 text-sm border-t border-gray-900 bg-dark">
        <p>&copy; 2025 MAHESH S. All rights reserved.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="script.js?v=1"></script>
</body>

</html>