// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Custom Cursor
const cursorDot = document.querySelector('.cursor-dot');
const cursorOutline = document.querySelector('.cursor-outline');

window.addEventListener('mousemove', (e) => {
    const posX = e.clientX;
    const posY = e.clientY;

    // Dot follows immediately
    cursorDot.style.left = `${posX}px`;
    cursorDot.style.top = `${posY}px`;

    // Outline follows with some delay/easing using GSAP
    gsap.to(cursorOutline, {
        x: posX,
        y: posY,
        duration: 0.15,
        ease: "power2.out"
    });
});

// Hover effects for links to expand cursor
const links = document.querySelectorAll('a, button, .project-card, .skill-card, .testimonial-card');
links.forEach(link => {
    link.addEventListener('mouseenter', () => {
        gsap.to(cursorOutline, {
            scale: 1.5,
            backgroundColor: "rgba(0, 242, 234, 0.1)",
            duration: 0.2
        });
    });
    link.addEventListener('mouseleave', () => {
        gsap.to(cursorOutline, {
            scale: 1,
            backgroundColor: "transparent",
            duration: 0.2
        });
    });
});

// Counter Animation Function
function animateCounter(element) {
    const target = parseInt(element.getAttribute('data-target'));
    const duration = 2;
    const increment = target / (duration * 60);
    let current = 0;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target + '+';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 1000 / 60);
}

// Hero Animation
const tl = gsap.timeline();

tl.to('.hero-subtitle', {
    y: 0,
    opacity: 1,
    duration: 1,
    ease: "power3.out",
    delay: 0.5
})
    .to('.hero-word-1', {
        y: 0,
        duration: 1.2,
        ease: "power4.out"
    }, "-=0.5")
    .to('.hero-word-2', {
        y: 0,
        duration: 1.2,
        ease: "power4.out"
    }, "-=0.9")
    .to('.hero-underline', {
        opacity: 1,
        scaleX: 1,
        duration: 0.8,
        ease: "power2.out"
    }, "-=0.3")
    .to('.hero-stats', {
        opacity: 1,
        duration: 0.8,
        ease: "power3.out",
        onComplete: () => {
            // Animate counters
            document.querySelectorAll('.counter').forEach(counter => {
                animateCounter(counter);
            });
        }
    }, "-=0.5")
    .to('.hero-desc', {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out"
    }, "-=0.5")
    .to('.hero-btn', {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out"
    }, "-=0.8")
    .to('.hero-line', {
        opacity: 1,
        duration: 0.5,
        stagger: 0.2
    }, "-=0.5")
    .to('.scroll-indicator', {
        opacity: 1,
        duration: 0.5
    }, "-=0.3");

// About Section Animation
gsap.to('.about-img-container', {
    scrollTrigger: {
        trigger: '#about',
        start: 'top 80%',
    },
    x: 0,
    opacity: 1,
    duration: 1.5,
    ease: "power3.out"
});

gsap.to('.about-text', {
    scrollTrigger: {
        trigger: '#about',
        start: 'top 80%',
    },
    x: 0,
    opacity: 1,
    duration: 1.5,
    ease: "power3.out",
    delay: 0.2
});

// Animate About Badge Counter
gsap.to('.counter-years', {
    scrollTrigger: {
        trigger: '.about-badge',
        start: 'top 90%',
        onEnter: () => {
            animateCounter(document.querySelector('.counter-years'));
        }
    }
});

// Animate Decorative Dots
gsap.to('.about-dots', {
    scrollTrigger: {
        trigger: '.about-dots',
        start: 'top 90%',
    },
    opacity: 1,
    duration: 0.8,
    ease: "power2.out"
});

// Work Section Animation
const projects = document.querySelectorAll('.project-card');
projects.forEach((project, index) => {
    gsap.from(project, {
        scrollTrigger: {
            trigger: project,
            start: 'top 85%',
        },
        y: 50,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        delay: index % 2 === 0 ? 0 : 0.2
    });
});

// Skills Section Animation
const skillCards = document.querySelectorAll('.skill-card');
skillCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: '#skills',
            start: 'top 80%',
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        ease: "back.out(1.7)",
        delay: index * 0.1
    });
});

// Animate Skill Bars
gsap.utils.toArray('.skill-bar').forEach(bar => {
    gsap.to(bar, {
        scrollTrigger: {
            trigger: bar,
            start: 'top 90%',
        },
        width: bar.getAttribute('data-width'),
        duration: 1.5,
        ease: "power2.out"
    });
});

// Testimonials Marquee Animation
const marquee = document.querySelector('.testimonial-marquee');

// Clone elements for infinite loop
const marqueeContent = marquee.innerHTML;
marquee.innerHTML += marqueeContent;

gsap.to(marquee, {
    xPercent: -50,
    ease: "none",
    duration: 20,
    repeat: -1
});

// Pause marquee on hover
marquee.addEventListener('mouseenter', () => {
    gsap.to(marquee, { timeScale: 0, duration: 0.5 });
});

marquee.addEventListener('mouseleave', () => {
    gsap.to(marquee, { timeScale: 1, duration: 0.5 });
});

// Resume Section Animation
const experienceItems = document.querySelectorAll('.experience-item');
experienceItems.forEach((item, index) => {
    gsap.to(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top 85%',
        },
        x: 0,
        opacity: 1,
        duration: 0.8,
        ease: "power3.out",
        delay: index * 0.15
    });
});

const educationItems = document.querySelectorAll('.education-item');
educationItems.forEach((item, index) => {
    gsap.to(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top 85%',
        },
        x: 0,
        opacity: 1,
        duration: 0.8,
        ease: "power3.out",
        delay: index * 0.15
    });
});

// Resume CTA Animation
gsap.to('.resume-cta', {
    scrollTrigger: {
        trigger: '.resume-cta',
        start: 'top 85%',
    },
    opacity: 1,
    y: 0,
    duration: 1,
    ease: "power3.out"
});

// Contact Section Animation
gsap.from('#contact h2', {
    scrollTrigger: {
        trigger: '#contact',
        start: 'top 80%',
    },
    y: 50,
    opacity: 0,
    duration: 1,
    ease: "power3.out"
});

gsap.from('#contact p', {
    scrollTrigger: {
        trigger: '#contact',
        start: 'top 80%',
    },
    y: 30,
    opacity: 0,
    duration: 1,
    delay: 0.2,
    ease: "power3.out"
});

// Parallax Effect for Hero Shapes
document.addEventListener('mousemove', (e) => {
    const x = (window.innerWidth - e.pageX * 2) / 100;
    const y = (window.innerHeight - e.pageY * 2) / 100;

    gsap.to('.hero-shapes div', {
        x: x,
        y: y,
        duration: 2,
        ease: "power2.out"
    });
});

// ========================================
// Features Section Animations
// ========================================

// Animate Features Header
gsap.from('.feature-header', {
    scrollTrigger: {
        trigger: '#features',
        start: 'top 80%',
    },
    y: 50,
    opacity: 0,
    duration: 1,
    ease: "power3.out"
});

// Animate Feature Cards with Stagger
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    gsap.to(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 85%',
        },
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: "back.out(1.5)",
        delay: index * 0.15
    });
});

// Animate Feature Progress Bars
gsap.utils.toArray('.feature-progress').forEach(bar => {
    gsap.to(bar, {
        scrollTrigger: {
            trigger: bar,
            start: 'top 90%',
        },
        width: bar.getAttribute('data-width'),
        duration: 1.5,
        ease: "power2.out"
    });
});

// Animate Development Skills Title
gsap.from('.dev-skills-title', {
    scrollTrigger: {
        trigger: '.dev-skills-title',
        start: 'top 85%',
    },
    y: 30,
    opacity: 0,
    duration: 0.8,
    ease: "power3.out"
});

// Animate Development Skill Items
const devSkills = document.querySelectorAll('.dev-skill');
devSkills.forEach((skill, index) => {
    gsap.to(skill, {
        scrollTrigger: {
            trigger: skill,
            start: 'top 90%',
        },
        opacity: 1,
        scale: 1,
        duration: 0.6,
        ease: "back.out(1.7)",
        delay: index * 0.1
    });
});

// Animate Circular Progress Bars
function animateCircularProgress(circle, percentText) {
    const percent = parseInt(circle.getAttribute('data-percent'));
    const radius = 56;
    const circumference = 2 * Math.PI * radius;

    // Calculate the dash offset for the target percentage
    const targetOffset = circumference - (percent / 100) * circumference;

    // Animate the circle
    gsap.to(circle, {
        scrollTrigger: {
            trigger: circle,
            start: 'top 90%',
        },
        strokeDashoffset: targetOffset,
        duration: 1.5,
        ease: "power2.out"
    });

    // Animate the percentage counter
    gsap.to({ value: 0 }, {
        scrollTrigger: {
            trigger: circle,
            start: 'top 90%',
        },
        value: percent,
        duration: 1.5,
        ease: "power2.out",
        onUpdate: function () {
            percentText.textContent = Math.round(this.targets()[0].value) + '%';
        }
    });
}

// Apply circular progress animation to all skill circles
const skillCircles = document.querySelectorAll('.skill-circle');
skillCircles.forEach((circle) => {
    const parent = circle.closest('.dev-skill');
    if (parent) {
        const percentText = parent.querySelector('.skill-percent');
        if (percentText) {
            animateCircularProgress(circle, percentText);
        }
    }
});

// Add hover effect to feature cards
document.querySelectorAll('.feature-card .glass-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        gsap.to(card, {
            y: -10,
            duration: 0.3,
            ease: "power2.out"
        });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            y: 0,
            duration: 0.3,
            ease: "power2.out"
        });
    });
});
