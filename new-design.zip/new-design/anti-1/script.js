// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Custom Cursor
const cursorDot = document.querySelector('.cursor-dot');
const cursorOutline = document.querySelector('.cursor-outline');

if (cursorDot && cursorOutline) {
    window.addEventListener('mousemove', (e) => {
        const posX = e.clientX;
        const posY = e.clientY;

        // Dot follows immediately
        cursorDot.style.left = `${posX}px`;
        cursorDot.style.top = `${posY}px`;

        // Outline follows with some delay/easing using GSAP
        gsap.to(cursorOutline, {
            x: posX,
            y: posY,
            duration: 0.15,
            ease: "power2.out"
        });
    });

    // Hover effects for links to expand cursor
    const links = document.querySelectorAll('a, button, .project-card, .skill-card');
    links.forEach(link => {
        link.addEventListener('mouseenter', () => {
            gsap.to(cursorOutline, {
                scale: 1.5,
                backgroundColor: "rgba(0, 242, 234, 0.1)",
                duration: 0.2
            });
        });
        link.addEventListener('mouseleave', () => {
            gsap.to(cursorOutline, {
                scale: 1,
                backgroundColor: "transparent",
                duration: 0.2
            });
        });
    });
}

// Hero Animation
const tl = gsap.timeline();

tl.to('.hero-subtitle', {
    y: 0,
    opacity: 1,
    duration: 1,
    ease: "power3.out",
    delay: 0.5
})
    .to('.hero-word-1', {
        y: 0,
        duration: 1.2,
        ease: "power4.out"
    }, "-=0.5")
    .to('.hero-word-2', {
        y: 0,
        duration: 1.2,
        ease: "power4.out"
    }, "-=0.9")
    .to('.hero-underline', {
        opacity: 1,
        scaleX: 1,
        duration: 0.8,
        ease: "power2.out"
    }, "-=0.3")
    .to('.hero-desc', {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out"
    }, "-=0.5")
    .to('.hero-btn', {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out"
    }, "-=0.8");

// About Section Animation
gsap.to('.about-image', {
    scrollTrigger: {
        trigger: '#about',
        start: 'top 80%',
    },
    x: 0,
    opacity: 1,
    duration: 1.5,
    ease: "power3.out"
});

gsap.to('.about-content', {
    scrollTrigger: {
        trigger: '#about',
        start: 'top 80%',
    },
    x: 0,
    opacity: 1,
    duration: 1.5,
    ease: "power3.out",
    delay: 0.2
});

// Work Section Animation
const projects = document.querySelectorAll('.project-card');
projects.forEach((project, index) => {
    gsap.from(project, {
        scrollTrigger: {
            trigger: project,
            start: 'top 85%',
        },
        y: 50,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        delay: index % 2 === 0 ? 0 : 0.2
    });
});

// Skills Section Animation
const skillCards = document.querySelectorAll('.skill-card');
skillCards.forEach((card, index) => {
    gsap.from(card, {
        scrollTrigger: {
            trigger: '#skills',
            start: 'top 80%',
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        ease: "back.out(1.7)",
        delay: index * 0.05
    });
});

// Features Animation
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    gsap.to(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 85%',
        },
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: "back.out(1.5)",
        delay: index * 0.15
    });
});

gsap.to('.feature-header', {
    scrollTrigger: {
        trigger: '#features',
        start: 'top 80%',
    },
    opacity: 1,
    y: 0,
    duration: 1,
    ease: "power3.out"
});

// Resume Section Animation
const experienceItems = document.querySelectorAll('.experience-item');
experienceItems.forEach((item, index) => {
    gsap.to(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top 85%',
        },
        x: 0,
        opacity: 1,
        duration: 0.8,
        ease: "power3.out",
        delay: index * 0.15
    });
});

const educationItems = document.querySelectorAll('.education-item');
educationItems.forEach((item, index) => {
    gsap.to(item, {
        scrollTrigger: {
            trigger: item,
            start: 'top 85%',
        },
        x: 0,
        opacity: 1,
        duration: 0.8,
        ease: "power3.out",
        delay: index * 0.15
    });
});

// Resume CTA Animation
gsap.to('.resume-cta', {
    scrollTrigger: {
        trigger: '.resume-cta',
        start: 'top 85%',
    },
    opacity: 1,
    y: 0,
    duration: 1,
    ease: "power3.out"
});

// Contact Section Animation
gsap.from('#contact h2', {
    scrollTrigger: {
        trigger: '#contact',
        start: 'top 80%',
    },
    y: 50,
    opacity: 0,
    duration: 1,
    ease: "power3.out"
});

gsap.from('#contact p', {
    scrollTrigger: {
        trigger: '#contact',
        start: 'top 80%',
    },
    y: 30,
    opacity: 0,
    duration: 1,
    delay: 0.2,
    ease: "power3.out"
});

// Parallax Effect for Hero Shapes
document.addEventListener('mousemove', (e) => {
    const x = (window.innerWidth - e.pageX * 2) / 100;
    const y = (window.innerHeight - e.pageY * 2) / 100;

    gsap.to('.hero-shapes div', {
        x: x,
        y: y,
        duration: 2,
        ease: "power2.out"
    });
});

// Magnetic Button Effect
const magneticButtons = document.querySelectorAll('.hero-btn a, nav a[href="#contact"], .resume-cta a');
magneticButtons.forEach(btn => {
    btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        gsap.to(btn, {
            x: x * 0.3,
            y: y * 0.3,
            duration: 0.3,
            ease: "power2.out"
        });
    });

    btn.addEventListener('mouseleave', () => {
        gsap.to(btn, {
            x: 0,
            y: 0,
            duration: 0.5,
            ease: "elastic.out(1, 0.3)"
        });
    });
});

// 3D Card Tilt
const tiltCards = document.querySelectorAll('.feature-card .glass-card, .skill-card, .project-card, .code-editor-card');
tiltCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        // Calculate rotation based on mouse position
        const rotateX = ((y - centerY) / centerY) * -10;
        const rotateY = ((x - centerX) / centerX) * 10;

        gsap.to(card, {
            rotationX: rotateX,
            rotationY: rotateY,
            transformPerspective: 1000,
            duration: 0.4,
            ease: "power2.out"
        });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            rotationX: 0,
            rotationY: 0,
            duration: 0.5,
            ease: "power2.out"
        });
    });
});

// Scroll Progress Line
const progressLine = document.createElement('div');
progressLine.style.position = 'fixed';
progressLine.style.top = '0';
progressLine.style.left = '0';
progressLine.style.height = '4px';
progressLine.style.width = '0%';
progressLine.style.background = 'linear-gradient(90deg, #00f2ea, #ff0055)';
progressLine.style.zIndex = '9999';
document.body.appendChild(progressLine);

gsap.to(progressLine, {
    width: '100%',
    scrollTrigger: {
        trigger: 'body',
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.5
    }
});

// Timeline Light Animation
gsap.to('.timeline-light', {
    scrollTrigger: {
        trigger: '.resume-experience',
        start: 'top 60%',
        end: 'bottom 60%',
        scrub: 1,
    },
    y: '500%',
    ease: 'none'
});
