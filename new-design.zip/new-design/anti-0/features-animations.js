// Features Section Animations
// Add this code to your script.js file

// Animate Features Header
gsap.from('.feature-header', {
    scrollTrigger: {
        trigger: '#features',
        start: 'top 80%',
    },
    y: 50,
    opacity: 0,
    duration: 1,
    ease: "power3.out"
});

// Animate Feature Cards with Stagger
const featureCards = document.querySelectorAll('.feature-card');
featureCards.forEach((card, index) => {
    gsap.to(card, {
        scrollTrigger: {
            trigger: card,
            start: 'top 85%',
        },
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: "back.out(1.5)",
        delay: index * 0.15
    });
});

// Animate Feature Progress Bars
gsap.utils.toArray('.feature-progress').forEach(bar => {
    gsap.to(bar, {
        scrollTrigger: {
            trigger: bar,
            start: 'top 90%',
        },
        width: bar.getAttribute('data-width'),
        duration: 1.5,
        ease: "power2.out"
    });
});

// Animate Development Skills Title
gsap.from('.dev-skills-title', {
    scrollTrigger: {
        trigger: '.dev-skills-title',
        start: 'top 85%',
    },
    y: 30,
    opacity: 0,
    duration: 0.8,
    ease: "power3.out"
});

// Animate Development Skill Items
const devSkills = document.querySelectorAll('.dev-skill');
devSkills.forEach((skill, index) => {
    gsap.to(skill, {
        scrollTrigger: {
            trigger: skill,
            start: 'top 90%',
        },
        opacity: 1,
        scale: 1,
        duration: 0.6,
        ease: "back.out(1.7)",
        delay: index * 0.1
    });
});

// Animate Circular Progress Bars
function animateCircularProgress(circle, percentText) {
    const percent = parseInt(circle.getAttribute('data-percent'));
    const radius = 56;
    const circumference = 2 * Math.PI * radius;

    // Calculate the dash offset for the target percentage
    const targetOffset = circumference - (percent / 100) * circumference;

    // Animate the circle
    gsap.to(circle, {
        scrollTrigger: {
            trigger: circle,
            start: 'top 90%',
        },
        strokeDashoffset: targetOffset,
        duration: 1.5,
        ease: "power2.out"
    });

    // Animate the percentage counter
    gsap.to({ value: 0 }, {
        scrollTrigger: {
            trigger: circle,
            start: 'top 90%',
        },
        value: percent,
        duration: 1.5,
        ease: "power2.out",
        onUpdate: function () {
            percentText.textContent = Math.round(this.targets()[0].value) + '%';
        }
    });
}

// Apply circular progress animation to all skill circles
const skillCircles = document.querySelectorAll('.skill-circle');
skillCircles.forEach((circle, index) => {
    const parent = circle.closest('.dev-skill');
    const percentText = parent.querySelector('.skill-percent');
    animateCircularProgress(circle, percentText);
});

// Add hover effect to feature cards
document.querySelectorAll('.feature-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        gsap.to(card, {
            y: -10,
            duration: 0.3,
            ease: "power2.out"
        });
    });

    card.addEventListener('mouseleave', () => {
        gsap.to(card, {
            y: 0,
            duration: 0.3,
            ease: "power2.out"
        });
    });
});
