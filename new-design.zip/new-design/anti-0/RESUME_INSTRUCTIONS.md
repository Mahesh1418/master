# Adding the Resume Section

## Instructions

To add the Resume/Experience section to your portfolio:

1. Open `index.html`
2. Find the line that says `<!-- Testimonials Section -->` (around line 587)
3. **Before** that line, copy and paste the entire content from `resume-section.html`

The Resume section includes:

### Features:
- **Timeline Design**: Professional vertical timeline with colored dots
- **Experience Column**: 
  - 3 job positions with company names, dates, and descriptions
  - Technology tags for each role
  - Hover effects on cards
  
- **Education Column**:
  - Master's and Bachelor's degrees
  - Certifications section
  - Timeline dots matching the design

- **Download Resume CTA**: 
  - Gradient button with download icon
  - Hover shadow effects
  - Centered glassmorphic card

### Animations (Already Added to script.js):
- ✅ Staggered fade-in for experience items
- ✅ Staggered fade-in for education items  
- ✅ Smooth reveal for download CTA
- ✅ Hover effects on timeline cards

### Visual Design:
- Glassmorphism cards
- Gradient backgrounds
- Timeline with colored dots (primary, secondary, purple)
- Technology tags with color-coded backgrounds
- Responsive grid layout (2 columns on desktop, stacked on mobile)

## Quick Copy-Paste Location:

```html
    </section>  <!-- End of Skills Section -->

    <!-- PASTE RESUME SECTION HERE -->

    <!-- Testimonials Section -->
```

The animations are already configured in `script.js`, so once you add the HTML, everything will work automatically!
